var data = 100;
var str = "Data From DataBase....!";
var flag = true;
function fun_one(arg1, arg2) {
    return fun_two(arg1, arg2);
}
function fun_two(arg1, arg2) {
    return arg1 + arg2;
}
