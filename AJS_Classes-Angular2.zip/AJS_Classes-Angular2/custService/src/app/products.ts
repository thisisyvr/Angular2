export class Products{
  constructor(public p_id:number,
              public p_name:string,
              public p_cost:number){

  }
}

