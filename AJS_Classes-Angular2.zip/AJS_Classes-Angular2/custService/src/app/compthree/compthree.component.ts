import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compthree',
  templateUrl: './compthree.component.html',
  styleUrls: ['./compthree.component.css']
})
export class CompthreeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
