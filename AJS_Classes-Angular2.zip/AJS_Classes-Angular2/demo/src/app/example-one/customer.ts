export class Customer{
  name:string="";
  age:number=0;
  sal:number=0;
}
