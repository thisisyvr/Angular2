import {Component} from "@angular/core";

@Component({
  selector:"ng-model",
  templateUrl:"./ng-model.html"
})
export class NgModelDemo{
  model_one:number=0;
  model_two:number=0;
}
