import {Component} from "@angular/core";

@Component({
  selector:"click",
  templateUrl:"./click.html"
})
export class Click{
  /*login(arg1,arg2){
    if(arg1 == "admin" && arg2=="admin"){
      alert("Login Success !");
    }else{
      alert("Login Fail !");
    }
  }*/

  /*login(arg1){
    if(arg1.uname=="admin" && arg1.upwd=="admin"){
      alert("Login Success !");
    }else{
      alert("Login Fail !");
    }
  }*/

  /*login_details={'uname':'','upwd':''};
  login(){
    if(this.login_details.uname=="admin" && this.login_details.upwd=="admin"){
      alert("Success !");
    }else{
      alert("Login Fail !");
    }
  }*/

  count=0;
}
